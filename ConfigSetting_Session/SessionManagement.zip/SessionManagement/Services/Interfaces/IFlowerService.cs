﻿using Core.Models;
using Core.Repositories.Interfaces;
using SessionManagement.Models;

namespace Core.Services.Interfaces
{
    public interface IFlowerService : IFlowerRepository
    {
        

    }
}
