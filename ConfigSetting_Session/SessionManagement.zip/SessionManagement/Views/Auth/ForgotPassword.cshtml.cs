using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SessionManagement.Views.Auth
{
    public class ForgotPasswordModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
