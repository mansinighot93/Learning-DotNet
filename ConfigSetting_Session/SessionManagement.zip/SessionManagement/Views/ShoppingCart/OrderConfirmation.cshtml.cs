using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SessionManagement.Views.ShoppingCart
{
    public class PaymentModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
